<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>
<body>
<div style="overflow: hidden;">
    <img class="img" src="logo2.jpg" alt="Food Haven Restaurant Logo" style="width: 100px; height: auto; float: left;" hspace="30" vspace="15">
    <h1 style="margin-left: 110px;margin-bottom: 110;">FOOD HAVEN RESTAURANT</h1>
  </div>
  <div class='topnav' >
    <a href='home.php'>Home</a>
    <a href='menu.php'>Menu</a>
    <a href='booking.php'>Booking</a>
    <a href='blog.php'>Blog</a>
    <a href='about.php'>About Us</a>
</div>
</body>
</html>