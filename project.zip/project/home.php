<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FOOD HAVEN RESTAURANT</title>
    <link href="style.css" rel="stylesheet">
    <link class="logo" rel="icon" type="/image" href="logo2.jpg">
</head>
<body>
<div>
    <?php
    include("header.php");
    ?>
</div>
    <img src="image.jpg" style="width: 500px; height: auto; float: left;" hspace="40" vspace="30">
    <h3 class="h3">Local fresh cuisine for everyone</h3>
    <p><b>Discover Our Local Flavors:</b> Experience the vibrant tastes of our region with locally sourced ingredients.<br><br><br>
        <b>Farm-to-Table Delights: </b>Our menu celebrates the bounty of nearby farms, ensuring freshness in every bite.<br><br><br>
        <b> Dishes:</b> From family recipe to innovate creations, our chefs bring the community together through  food.</p><br><br><br><br>

    <img src="image2.jpg" style="width: 500px; height: auto; float: left;" hspace="40" vspace="30">
    <p style="float: right;">
    <br><br><br><b>Seasonal Specialties:</b> Explore our ever-changing menu, featuring dishes inspired by the changing seasons.<br><br><br>
    <b>Your Culinary Journey Starts Here:</b> Join us for a memorable dining experience that celebrates local cuisine.<br><br><br>
    <b>Chef's Signature Dishes:</b> Indulge in culinary masterpieces crafted by our talented chefs.<br><br><br>
    <b>Local Pairings: </b>Explore our curated wine and beer selection, perfectly complementing each dish.<br><br><br><br><br><br><br><br>
    </p>

    <img src="image3.jpeg" style="width: 500px; height: auto; float: left;" hspace="40" vspace="30">
    <p><b>Cozy Ambiance:</b> Our warm and inviting space sets the stage for memorable dining moments.<br><br><br>
        <b>Weekly Specials:</b> Don't miss out on our rotating specials, featuring unique creations every week.<br><br><br>
        <b>Book Your Table:</b> Reserve now to savor the essence of local cuisine at its finest!
    </p>
</body>
</html>