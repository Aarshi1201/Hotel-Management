<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FOOD HAVEN RESTAURANT</title>
    <link href="style.css" rel="stylesheet">
    <link rel="icon" type="/image" href="logo2.jpg">
</head>
<body>
<div><?php include("header.php");?></div><br>
<h2 style="color:rgb(51, 33, 25); font-family:'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif; margin-left:50px" >Here is the splendid view of our restaurant at various places in world...</h2><br>
<div style="width:100%;float: left;">
    <div style="width:47%;float: left;margin-left:80px">  
    <b>Ahmedabad</b>
    <iframe width="550" height="340" src="https://www.youtube.com/embed/oQ3zW_4LJWk" title="Ahmedabad’s iconic Patang Hotel starts revolving after four years of break" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
    </div>
    <div style="width:47%;float: left;">
    <b>Sakleshpur</b>
      <iframe width="550" height="340" src="https://www.youtube.com/embed/3kzLsSG9FNc" title="Rosetta by Ferns - Sakleshpur | Property Tour (4K) | Restaurants | Nature | Luxury Resort" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
      </div>
</div>
<br>
<div style="width:100%;float: left;">
  <div style="width:47%;float: left;margin-left:80px">   <b >Delhi</b><br>
  <iframe width="550" height="340" src="https://www.youtube.com/embed/FSfwIqbirJ0" title="India&#39;s No. 1 Restaurant - Indian Accent with Manish Mehrotra" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
  </div>
  <div style="width:47%;float: left;"><b>Goa</b><br>
  <iframe width="550" height="340" src="https://www.youtube.com/embed/lGdPVTEnBWU" title="Amara Grand Restaurant View| Baga Beach| Food view| Buffett system for Breakfast| GOA" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
    </div>
</div>
</body>
</html>