<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FOOD HAVEN RESTAURANT</title>
    <link href="style.css" rel="stylesheet">
    <link rel="icon" type="/image" href="logo2.jpg">
</head>
<body>
<div><?php include("header.php");?></div>
<div class="row">
  <div class="col punjabi box">
   <h4 style="font-size: larger; margin:8px;">Punjabi Food</h3>
    <ul style="color:rgb(21, 6, 75)">
    <li>210/- Palak Paneer</li>
    <li>270/- Paneer Bhurji</li>
    <li>240/- Paneer Butter Masala</li>
    <li>280/- Paneer Kofta</li>
    <li>200/- Chana Masala</li>
    <li>280/- Kaju Paneer Masala</li>
    <li>260/- Paneer Pasanda</li>
    <li>220/- Veg. Kolhapuri</li>
    <li>220/- Veg. Haidrabadi</li>
    <li>230/- Paneer Tikka</li></ul>
</div>
<div class="col southindian box">
  <h4 style="font-size: larger; margin:8px;">South Indian Food</h3>
    <ul style="color:rgb(21, 6, 75)">
    <li>50/- Medu Vada</li>
    <li>60/- Sambhar Vada</li>
    <li>240/- Butter Dosa</li>
    <li>65/- Dahi Vada</li>
    <li>40/- Steam Idli</li>
    <li>119/- Masala Dosa</li>
    <li>129/- Cheese Dosa</li>
    <li>119/- Mysore Dosa</li>
    <li>119/- Paneer Masala Dosa</li>
    <li>129/- Schezwan Masala Dosa</li></ul>
</div>
<div class="col rajasthani box">
  <h4 style="font-size: larger; margin:8px;">Rajasthani Food</h3>
    <ul style="color:rgb(21, 6, 75)">
    <li>80/- Steamed Rice</li>
    <li>100/- Boondi Raita</li>
    <li>45/- Butter Naan</li>
    <li>120/- Daal Baati Churma</li>
    <li>90/- Mirchi Vada</li>
    <li>75/- Kachori</li>
    <li>125/- Ker Sangri</li>
    <li>140/- Gatte Ki Sabji</li>
    <li>55/- Lachha Paratha</li>
    <li>70/- Mohanthal</li></ul>
</div>
<div class="col italian box">
<h4 style="font-size: larger; margin:8px;">Italian Food</h3>
  <ul style="color:rgb(21, 6, 75)">
  <li>1000/- Margherita Pizza</li>
  <li>1200/- Pasta Primavera</li>
  <li>860/- Caprese Salad</li>
  <li>1145/- Gnocchi with Pesto Sauce</li>
  <li>1540/- Risotto ai Funghi</li>
  <li>650/- Bruschetta</li>
  <li>1490/- Spinach and Ricotta Ravioli</li>
  <li>900/- Minestrone Soup</li>
  <li>590/- Focaccia</li>
  <li>1650/- Lasagna al Forn</li></ul>
</div>
</div>
<div class="col gujarati box">
  <h4 style="font-size: larger; margin:8px;">Gujarati Food</h3>
    <ul style="color:rgb(21, 6, 75)">
    <li>50/- Dhokla</li>
    <li>25/- Thepla</li>
    <li>250/- Undhiyu</li>
    <li>60/- Khandvi</li>
    <li>70/- Fafda Jalebi</li>
    <li>70/- Handvo</li>
    <li>60/- Patraa</li>
    <li>40/- Khichu</li>
    <li>120/- Sev Tameta Sabji</li>
    <li>160/- Shrikhand</li></ul>
</div>
<div class="col maharashtrian box">
  <h4 style="font-size: larger; margin:8px;">Maharashtrian Food</h3>
    <ul style="color:rgb(21, 6, 75)">
    <li>120/- Pav Bhaji</li>
    <li>40/- VadaPav</li>
    <li>50/- Puran Poli</li>
    <li>130/- Misal Pav</li>
    <li>39/- Thalipeeth</li>
    <li>45/- Sol Kadhi</li>
    <li>90/-Sabudana Khichdi</li>
    <li>35/- Modak</li>
    <li>40/- Batata Vada</li>
    <li>110/- Aamti</li></ul>
</div>
</body>
</html>